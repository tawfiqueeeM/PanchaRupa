# PanchaRupa synthetic data · Department 3

These fixtures are synthetic and intended for the virtual factory. The two reported endpoint figures in growth_context.csv are founder recollection, with the proposed coordinated design anchored to the upper figure. There are no historic records in these files. No temperatures, energy values, tolerances, prices or speeds here are specifications for real machinery.

## Use the fixtures

- DAY-40 starts at 08:00. All *_min fields are elapsed minutes from that time. Station reservations and outages are half-open intervals. The worker listed against each station is reserved for its full interval in the baseline, even where hands-on minutes are lower.
- DAY-40 is a single integration test. It uses 120 kg green-grade leaf and 40 kg golden-eligible leaf at 25% net yield to produce 30 kg green and 10 kg golden. Each product allocates 2 kg to retail as twenty 50 g and ten 100 g bottles. The rest goes to bulk.
- MONTH-VAR uses 29 operating days out of 30 with varying daily output. Golden tea releases only on days with suitable leaf; 25% yield is illustrative for both products. Monthly allocation tables show one synthetic month; cost_inputs.csv remains a separate round-number design-month financial example using 1,000 kg and its own packaging mix. None of the bag sizes, leaf grading settings or prices is a historical or broker specification.
- DAY-OUTAGE overlaps the golden tea dry cycle, so apply it as an override and reschedule. SHIFT-ABSENT removes W-02 and may leave work uncovered. PACK-REJECT is a separate example and does not subtract from the nominal day's 40 kg.
- Join vendor_lot_id to lot_id and batch_id or finished_lot_id across production, quality and packing. Join order_id to orders and dispatch. Worker skill lists are pipe-delimited.
- DRY-NORMAL and DRY-FAULT use separate clocks in seconds. start_request, ack_request and reset_request are single-scan pulses. fan_proof starts true and changes only when commanded in the input table. The setpoint is 60 °C and initial model temperature is 28 °C. Sample every 5 seconds. The reference model applies events before sampling, then advances temperature by 5 × (0.35 × heat_command − (temperature − 28)/240). Heat is on below setpoint only if a run is active and proof is present. An active loss latches a fault and stops the run. Acknowledgement does not reset. Restore proof, reset, and explicitly restart. The trace is generated reference data, not an observation from a deployed app or plant.
- Acceptance cases are expected behavior. The schedule assumes planned release rather than observed production.
- Currency is BDT. Unit manufacturing cost includes leaf, packaging, recurring factory costs and straight-line depreciation. Outbound freight is a separate selling cost.

## Included tables

- scenario_catalog.csv (7 records)
- monthly_leaf_supply.csv (30 records)
- monthly_output.csv (30 records)
- monthly_retail_mix.csv (30 records)
- dryer_tags.csv (8 records)
- dryer_event_inputs.csv (7 records)
- dryer_reference_trace.csv (122 records)
- station_schedule.csv (13 records)
- day_overrides.csv (2 records)
